import React, { useState, useEffect, useCallback } from "react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../services/api";
import { Product } from "../types";
import { useAuth } from "../context/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { 
  Plus, 
  Search, 
  ChevronLeft, 
  ChevronRight, 
  Trash2, 
  Edit3, 
  Eye, 
  Grid, 
  List, 
  SlidersHorizontal,
  ChevronDown,
  AlertTriangle,
  X,
  PlusCircle,
  FolderOpen
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function ProductList() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // State Management
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Search state
  const [searchKeyword, setSearchKeyword] = useState("");
  const [activeKeyword, setActiveKeyword] = useState(""); // Word sent to API

  // Pagination parameters (zero-indexed to match Spring Boot Pageable)
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(6);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);

  // Sorting configurations
  const [sortBy, setSortBy] = useState("productName");
  const [direction, setDirection] = useState("asc");

  // Visual layout mode: "grid" vs "table"
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");

  // Deletion modal state
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleteName, setDeleteName] = useState<string>("");
  const [deleting, setDeleting] = useState(false);

  // Fetching products from Backend API
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Determine if calling standard paginated API or search API
      const endpoint = activeKeyword ? "/products/search" : "/products";
      const response = await api.get(endpoint, {
        params: {
          page: page,
          size: pageSize,
          sortBy: sortBy,
          direction: direction,
          keyword: activeKeyword || undefined,
        },
      });

      setProducts(response.data.content || []);
      setTotalPages(response.data.totalPages || 0);
      setTotalElements(response.data.totalElements || 0);
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to load product list. Please verify connection to backend port.");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, sortBy, direction, activeKeyword]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Handlers
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(0); // Reset page to 0 on new search keyword
    setActiveKeyword(searchKeyword);
  };

  const handleClearSearch = () => {
    setSearchKeyword("");
    setActiveKeyword("");
    setPage(0);
  };

  const openDeleteModal = (id: number, name: string) => {
    setDeleteId(id);
    setDeleteName(name);
  };

  const closeDeleteModal = () => {
    setDeleteId(null);
    setDeleteName("");
  };

  const handleDeleteConfirm = async () => {
    if (deleteId === null) return;
    setDeleting(true);
    try {
      await api.delete(`/products/${deleteId}`);
      closeDeleteModal();
      fetchProducts(); // Reload product table
    } catch (err: any) {
      alert(err.response?.data?.message || "Failed to delete product");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header section */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Product Catalog</h1>
            <p className="text-slate-500 text-sm mt-0.5">Search, inventory audit, and manage standard physical stocks.</p>
          </div>
          {user?.role === "ADMIN" && (
            <Link
              to="/products/add"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold shadow-md hover:bg-slate-950 transition-all cursor-pointer"
            >
              <Plus size={16} />
              <span>Add New Product</span>
            </Link>
          )}
        </div>

        {/* Toolbar panel (Search, sort, view toggles) */}
        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm flex flex-col gap-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            {/* Search Input Form */}
            <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md relative">
              <input
                type="text"
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                placeholder="Search products by title, category, brand..."
                className="w-full pl-10 pr-10 py-2 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 bg-slate-50/50"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search size={16} />
              </div>
              {searchKeyword && (
                <button
                  type="button"
                  onClick={handleClearSearch}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <X size={16} />
                </button>
              )}
            </form>

            {/* Sorting & Views Controls */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Sort field dropdown */}
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl px-3 py-2 bg-slate-50/50 text-xs">
                <SlidersHorizontal size={14} className="text-slate-400" />
                <span className="font-semibold text-slate-500">Sort By</span>
                <select
                  value={sortBy}
                  onChange={(e) => {
                    setSortBy(e.target.value);
                    setPage(0);
                  }}
                  className="bg-transparent font-bold text-slate-700 outline-none cursor-pointer"
                >
                  <option value="productName">Product Name</option>
                  <option value="price">Price</option>
                  <option value="quantity">Stock Quantity</option>
                  <option value="brand">Brand Name</option>
                  <option value="category">Category</option>
                </select>
              </div>

              {/* Sort direction toggle */}
              <button
                onClick={() => {
                  setDirection(direction === "asc" ? "desc" : "asc");
                  setPage(0);
                }}
                className="border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 transition"
              >
                {direction === "asc" ? "Ascending ↑" : "Descending ↓"}
              </button>

              {/* View Layout Mode (Grid/Table) */}
              <div className="border border-slate-200 rounded-xl p-1 bg-slate-50 flex gap-0.5">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-1.5 rounded-lg transition-all ${
                    viewMode === "grid" ? "bg-white text-slate-800 shadow-sm" : "text-slate-400 hover:text-slate-600"
                  }`}
                  title="View as Cards"
                  id="viewmode-grid-btn"
                >
                  <Grid size={16} />
                </button>
                <button
                  onClick={() => setViewMode("table")}
                  className={`p-1.5 rounded-lg transition-all ${
                    viewMode === "table" ? "bg-white text-slate-800 shadow-sm" : "text-slate-400 hover:text-slate-600"
                  }`}
                  title="View as Table"
                  id="viewmode-table-btn"
                >
                  <List size={16} />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Catalog error prompt */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center gap-3">
            <X size={20} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Loader list animations */}
        {loading ? (
          <div className="text-center py-20 min-h-[300px]">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-slate-900 mx-auto"></div>
            <p className="text-slate-400 mt-4 text-sm font-semibold">Synchronizing catalog database records...</p>
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-xl mx-auto space-y-4">
            <div className="h-14 w-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center mx-auto">
              <FolderOpen size={28} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800">No products found</h3>
              <p className="text-slate-500 text-sm mt-1">
                We couldn't locate any catalog listings matching "{activeKeyword}" in database records.
              </p>
            </div>
            {activeKeyword && (
              <button
                onClick={handleClearSearch}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all"
              >
                Clear Search Query
              </button>
            )}
          </div>
        ) : viewMode === "grid" ? (
          // Grid View Layout
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((p) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ y: -3 }}
                transition={{ duration: 0.2 }}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="h-48 w-full bg-slate-100 relative overflow-hidden group">
                    <img
                      src={p.imageUrl}
                      alt={p.productName}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3">
                      <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-white text-slate-800 shadow-sm border border-slate-100">
                        {p.category}
                      </span>
                    </div>
                  </div>

                  <div className="p-5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-400 uppercase">{p.brand}</span>
                      <span className="text-sm font-extrabold text-slate-900">${p.price.toFixed(2)}</span>
                    </div>
                    <h3 className="font-bold text-slate-800 text-base leading-snug line-clamp-1">{p.productName}</h3>
                    <p className="text-slate-500 text-xs leading-relaxed line-clamp-2">{p.description}</p>
                  </div>
                </div>

                <div className="p-5 pt-0 border-t border-slate-100 mt-4 flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-450 text-slate-400 font-semibold">
                    Stock: <span className="font-bold text-slate-700">{p.quantity} units</span>
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => navigate(`/products/details/${p.id}`)}
                      className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-50 border border-slate-150 border-slate-200 rounded-xl transition"
                      title="View Details"
                    >
                      <Eye size={14} />
                    </button>
                    {user?.role === "ADMIN" && (
                      <>
                        <button
                          onClick={() => navigate(`/products/edit/${p.id}`)}
                          className="p-2 text-blue-500 hover:text-blue-700 hover:bg-blue-50 border border-blue-100 rounded-xl transition"
                          title="Edit Details"
                        >
                          <Edit3 size={14} />
                        </button>
                        <button
                          onClick={() => openDeleteModal(p.id, p.productName)}
                          className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 border border-red-100 rounded-xl transition"
                          title="Delete Product"
                        >
                          <Trash2 size={14} />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          // Table list layout
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-100 text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-3.5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Product Description</th>
                    <th className="px-6 py-3.5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-3.5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Brand</th>
                    <th className="px-6 py-3.5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Price</th>
                    <th className="px-6 py-3.5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Quantity</th>
                    <th className="px-6 py-3.5 text-right text-xs font-bold text-slate-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50 transition">
                      <td className="px-6 py-3.5 flex items-center gap-3">
                        <img 
                          src={p.imageUrl} 
                          alt={p.productName} 
                          referrerPolicy="no-referrer"
                          className="h-10 w-10 rounded-lg object-cover bg-slate-150 border border-slate-200" 
                        />
                        <div className="flex flex-col">
                          <span className="font-bold text-slate-900">{p.productName}</span>
                          <span className="text-xs text-slate-400 font-medium max-w-xs truncate">{p.description}</span>
                        </div>
                      </td>
                      <td className="px-6 py-3.5 text-slate-600 font-medium">{p.category}</td>
                      <td className="px-6 py-3.5 text-slate-600 font-medium">{p.brand}</td>
                      <td className="px-6 py-3.5 font-bold text-slate-900">${p.price.toFixed(2)}</td>
                      <td className="px-6 py-3.5 font-mono text-slate-600">{p.quantity} units</td>
                      <td className="px-6 py-3.5 text-right flex items-center justify-end gap-1.5 h-16">
                        <button
                          onClick={() => navigate(`/products/details/${p.id}`)}
                          className="p-1 px-2.5 text-slate-600 hover:text-slate-800 hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1"
                        >
                          <Eye size={12} />
                          Details
                        </button>
                        {user?.role === "ADMIN" && (
                          <>
                            <button
                              onClick={() => navigate(`/products/edit/${p.id}`)}
                              className="p-1.5 text-blue-500 hover:text-blue-700 hover:bg-blue-50 border border-blue-100 rounded-xl transition"
                            >
                              <Edit3 size={13} />
                            </button>
                            <button
                              onClick={() => openDeleteModal(p.id, p.productName)}
                              className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 border border-red-100 rounded-xl transition"
                            >
                              <Trash2 size={13} />
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl shadow-sm">
            <span className="text-xs text-slate-500 font-medium">
              Showing page <span className="font-bold text-slate-800">{page + 1}</span> of <span className="font-bold text-slate-800">{totalPages}</span> ({totalElements} items total)
            </span>
            <div className="inline-flex items-center gap-1 bg-slate-50 border border-slate-100 p-1.5 rounded-xl">
              <button
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="p-1 text-slate-650 text-slate-500 hover:bg-white enabled:hover:text-slate-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition"
              >
                <ChevronLeft size={16} />
              </button>
              
              {Array.from({ length: totalPages }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setPage(idx)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    page === idx 
                      ? "bg-slate-900 text-white shadow-sm" 
                      : "text-slate-500 hover:bg-white hover:text-slate-800"
                  }`}
                >
                  {idx + 1}
                </button>
              ))}

              <button
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page >= totalPages - 1}
                className="p-1 text-slate-650 text-slate-500 hover:bg-white enabled:hover:text-slate-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Overlay Dialog Modal */}
      <AnimatePresence>
        {deleteId !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={closeDeleteModal}
              className="absolute inset-0 bg-slate-950"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden relative z-10"
            >
              <div className="p-6">
                <div className="flex gap-4 items-start">
                  <div className="h-10 w-10 bg-red-50 text-red-600 rounded-xl flex items-center justify-center shrink-0 border border-red-100">
                    <AlertTriangle size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Confirm Deletion</h3>
                    <p className="text-sm text-slate-500 mt-2">
                      Are you sure you want to delete <span className="font-bold text-slate-800">"{deleteName}"</span> from the product inventory listings? This operation cannot be undone.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 px-6 py-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={closeDeleteModal}
                  className="px-4 py-2 border border-slate-200 text-slate-600 bg-white hover:bg-slate-50 hover:border-slate-350 rounded-xl text-xs font-semibold cursor-pointer transition-all"
                  id="cancel-delete-btn"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  disabled={deleting}
                  className="px-4 py-2 text-white bg-red-600 hover:bg-red-700 disabled:bg-red-400 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  id="confirm-delete-btn"
                >
                  <Trash2 size={13} />
                  {deleting ? "Deleting..." : "Permanently Delete"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </DashboardLayout>
  );
}
