import React, { createContext, useContext, useState, useEffect } from "react";
import api from "../services/api";

interface AuthUser {
  userId: number;
  email: string;
  fullName: string;
  role: "ADMIN" | "USER";
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<any>;
  register: (fullName: string, email: string, password: string, role: string) => Promise<any>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Auto-login checking localStorage
    const savedToken = localStorage.getItem("token");
    const savedRole = localStorage.getItem("role") as "ADMIN" | "USER" | null;
    const savedEmail = localStorage.getItem("email");
    const savedFullName = localStorage.getItem("fullName");
    const savedUserId = localStorage.getItem("userId");

    if (savedToken && savedRole && savedEmail && savedFullName && savedUserId) {
      setToken(savedToken);
      setUser({
        userId: parseInt(savedUserId),
        email: savedEmail,
        fullName: savedFullName,
        role: savedRole,
      });
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const response = await api.post("/auth/login", { email, password });
      const { token, role, email: returnedEmail, fullName, userId } = response.data;

      localStorage.setItem("token", token);
      localStorage.setItem("role", role);
      localStorage.setItem("email", returnedEmail);
      localStorage.setItem("fullName", fullName);
      localStorage.setItem("userId", String(userId));

      setToken(token);
      setUser({
        userId,
        email: returnedEmail,
        fullName,
        role,
      });
      return response.data;
    } catch (error: any) {
      throw error.response?.data?.message || "Invalid credentials. Please try again.";
    }
  };

  const register = async (fullName: string, email: string, password: string, role: string) => {
    try {
      const response = await api.post("/auth/register", { fullName, email, password, role });
      return response.data;
    } catch (error: any) {
      throw error.response?.data?.message || "Registration failed. Please try again.";
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("email");
    localStorage.removeItem("fullName");
    localStorage.removeItem("userId");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
