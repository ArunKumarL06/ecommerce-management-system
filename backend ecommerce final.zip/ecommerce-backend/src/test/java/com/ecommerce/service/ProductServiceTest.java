package com.ecommerce.service;

import com.ecommerce.dto.ProductDto;
import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    private Product mockProduct;
    private ProductDto mockDto;

    @BeforeEach
    void setUp() {
        mockProduct = Product.builder()
                .id(1L)
                .productName("Sample Watch")
                .brand("BrandX")
                .category("Electronics")
                .price(new BigDecimal("199.99"))
                .quantity(10)
                .imageUrl("http://example.com/pic.jpg")
                .build();

        mockDto = ProductDto.builder()
                .productName("Sample Watch")
                .brand("BrandX")
                .category("Electronics")
                .price(new BigDecimal("199.99"))
                .quantity(10)
                .build();
    }

    @Test
    void testGetProductById_Success() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(mockProduct));

        ProductDto found = productService.getProductById(1L);

        assertNotNull(found);
        assertEquals("Sample Watch", found.getProductName());
        assertEquals("BrandX", found.getBrand());
        verify(productRepository, times(1)).findById(1L);
    }

    @Test
    void testGetProductById_ThrowsResourceNotFoundException() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            productService.getProductById(99L);
        });

        verify(productRepository, times(1)).findById(99L);
    }

    @Test
    void testCreateProduct_Success() {
        when(productRepository.save(any(Product.class))).thenReturn(mockProduct);

        ProductDto saved = productService.createProduct(mockDto);

        assertNotNull(saved);
        assertEquals("Sample Watch", saved.getProductName());
        verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void testDeleteProduct_Success() {
        when(productRepository.existsById(1L)).thenReturn(true);
        doNothing().when(productRepository).deleteById(1L);

        assertDoesNotThrow(() -> productService.deleteProduct(1L));

        verify(productRepository, times(1)).existsById(1L);
        verify(productRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteProduct_ThrowsResourceNotFound_WhenIdNotExists() {
        when(productRepository.existsById(99L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> {
            productService.deleteProduct(99L);
        });

        verify(productRepository, times(1)).existsById(99L);
        verify(productRepository, never()).deleteById(anyLong());
    }
}
