import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../services/api";
import { Product } from "../types";
import { useNavigate, useParams, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { 
  ArrowLeft, 
  Tag, 
  Layers, 
  ShieldAlert, 
  Edit3, 
  Clock, 
  Grid, 
  ShoppingBag,
  TrendingUp,
  Boxes
} from "lucide-react";
import { motion } from "motion/react";

export default function ProductDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await api.get(`/products/${id}`);
        setProduct(response.data);
      } catch (err: any) {
        console.error(err);
        setError(err.response?.data?.message || "Product not found or database sync failed.");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchProduct();
    }
  }, [id]);

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6 font-sans">
        
        {/* Breadcrumb row */}
        <div className="flex items-center justify-between">
          <Link 
            to="/products" 
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition"
          >
            <ArrowLeft size={14} />
            <span>Back to Catalog</span>
          </Link>

          {user?.role === "ADMIN" && product && (
            <Link
              to={`/products/edit/${product.id}`}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 border border-blue-200 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl text-xs font-bold transition-all"
            >
              <Edit3 size={12} />
              <span>Modify Details</span>
            </Link>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center gap-3 text-sm">
            <ShieldAlert size={18} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {loading ? (
          <div className="text-center py-24 bg-white border border-slate-200 rounded-2xl shadow-sm">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900 mx-auto"></div>
            <p className="text-slate-400 mt-4 text-xs font-semibold">Pulling listing statistics...</p>
          </div>
        ) : product ? (
          <div className="bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-2">
            
            {/* Left side: Image container */}
            <div className="bg-slate-50 flex items-center justify-center p-6 border-b md:border-b-0 md:border-r border-slate-200 min-h-[350px]">
              <motion.img
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                src={product.imageUrl}
                alt={product.productName}
                referrerPolicy="no-referrer"
                className="max-h-[350px] w-full object-cover rounded-xl shadow-md border border-slate-200"
              />
            </div>

            {/* Right side: Information block */}
            <div className="p-6 md:p-8 flex flex-col justify-between">
              <div className="space-y-6">
                
                {/* Taxonomy & Header */}
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-2 items-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
                      {product.brand}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-100">
                      {product.category}
                    </span>
                  </div>
                  <h1 className="text-2xl font-black text-slate-900 leading-tight">{product.productName}</h1>
                </div>

                {/* Economics highlight */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Recommended Retail Price</span>
                    <span className="text-2xl font-black text-slate-900 mt-1">${product.price.toFixed(2)}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Status</span>
                    <span className={`inline-flex px-2 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      product.quantity > 50 
                        ? "bg-emerald-100 text-emerald-800 border border-emerald-200" 
                        : product.quantity > 0 
                          ? "bg-amber-100 text-amber-800 border border-amber-200" 
                          : "bg-red-100 text-red-800 border border-red-200"
                    }`}>
                      {product.quantity > 50 ? "Healthy Stock" : product.quantity > 0 ? "Minimal Counts" : "Out Of Stock"}
                    </span>
                  </div>
                </div>

                {/* Description Copy */}
                <div className="space-y-2 text-sm leading-relaxed text-slate-600">
                  <h3 className="font-bold text-slate-800 flex items-center gap-1">
                    <ShoppingBag size={14} className="text-slate-400" />
                    Listing Specification
                  </h3>
                  <p>{product.description || "No customized copy provided for this listing."}</p>
                </div>

                {/* Warehouse facts */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100 text-xs text-slate-500 font-semibold">
                  <div className="flex items-center gap-2">
                    <Boxes size={15} className="text-slate-450 text-slate-400" />
                    <span>Inventory capacity: <span className="text-slate-800 font-bold">{product.quantity} counts</span></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={15} className="text-slate-450 text-slate-400" />
                    <span>Resource reference: <span className="text-slate-800 font-mono font-bold">#SKU-{product.id}</span></span>
                  </div>
                </div>

              </div>

              {/* Dynamic audit meta dates */}
              <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col justify-end text-[10px] font-mono text-slate-400 space-y-1">
                <span>Created at: {new Date(product.createdAt).toLocaleString()}</span>
                <span>Last compiled update: {new Date(product.updatedAt).toLocaleString()}</span>
              </div>

            </div>

          </div>
        ) : (
          <div className="p-8 text-center text-slate-500">
            Empty listing model response.
          </div>
        )}

      </div>
    </DashboardLayout>
  );
}
