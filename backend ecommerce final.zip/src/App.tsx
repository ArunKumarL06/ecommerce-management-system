/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import PrivateRoute from "./components/PrivateRoute";

// Pages import
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ProductList from "./pages/ProductList";
import AddProduct from "./pages/AddProduct";
import EditProduct from "./pages/EditProduct";
import ProductDetails from "./pages/ProductDetails";
import Unauthorized from "./pages/Unauthorized";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Auth Routers */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Core Private Dashboards */}
          <Route 
            path="/dashboard" 
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/products" 
            element={
              <PrivateRoute>
                <ProductList />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/products/add" 
            element={
              <PrivateRoute allowedRoles={["ADMIN"]}>
                <AddProduct />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/products/edit/:id" 
            element={
              <PrivateRoute allowedRoles={["ADMIN"]}>
                <EditProduct />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/products/details/:id" 
            element={
              <PrivateRoute>
                <ProductDetails />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/unauthorized" 
            element={
              <PrivateRoute>
                <Unauthorized />
              </PrivateRoute>
            } 
          />

          {/* Catch-all Routing */}
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

