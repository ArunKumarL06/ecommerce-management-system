package com.ecommerce.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDto {

    private Long id;

    @NotBlank(message = "Product name must not be blank")
    private String productName;

    private String description;

    @NotBlank(message = "Category field is required")
    private String category;

    @NotBlank(message = "Brand field is required")
    private String brand;

    @NotNull(message = "Product price must be specified")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price possesses positive validations constraint")
    private BigDecimal price;

    @NotNull(message = "Product listing slot quantity is required")
    @Min(value = 0, message = "Stock slot inventory count cannot be negative")
    private Integer quantity;

    private String imageUrl;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
