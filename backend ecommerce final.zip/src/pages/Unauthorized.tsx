import React from "react";
import { Link } from "react-router-dom";
import { ShieldAlert, ArrowLeft, LayoutDashboard } from "lucide-react";
import { motion } from "motion/react";

export default function Unauthorized() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4 font-sans text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="max-w-md w-full bg-white border border-slate-200 shadow-xl rounded-2xl p-8 space-y-6"
      >
        <div className="h-16 w-16 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto border border-red-100 shadow-sm">
          <ShieldAlert size={32} />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Access Denied</h1>
          <p className="text-slate-500 text-sm">
            You do not possess the required administrator credentials to access this warehouse module resource.
          </p>
        </div>

        <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-left text-xs space-y-1.5 font-medium text-slate-600">
          <span className="font-bold text-slate-700 uppercase tracking-wide block text-[10px]">Permission Notice</span>
          <p>Writing, editing or deleting catalog listings is strictly reserved for user roles matching: <code className="font-mono bg-slate-200/50 px-1 py-0.5 rounded font-black text-red-600">ADMIN</code>.</p>
        </div>

        <div className="grid grid-cols-2 gap-3.5 pt-2">
          <Link
            to="/products"
            className="flex items-center justify-center gap-1.5 p-2.5 border border-slate-200 hover:bg-slate-50 hover:border-slate-350 rounded-xl text-xs font-semibold text-slate-600 transition-all"
          >
            <ArrowLeft size={13} />
            <span>Product Catalog</span>
          </Link>
          <Link
            to="/dashboard"
            className="flex items-center justify-center gap-1.5 p-2.5 bg-slate-900 hover:bg-slate-950 rounded-xl text-xs font-bold text-white shadow transition-all"
          >
            <LayoutDashboard size={13} />
            <span>Dashboard</span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
