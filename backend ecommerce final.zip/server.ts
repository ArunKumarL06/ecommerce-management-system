import express from "express";
import path from "path";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const JWT_SECRET = "super-secret-key-for-java-equivalent-jwt-token-signing";

app.use(express.json());

// In-memory Database
interface User {
  id: number;
  fullName: string;
  email: string;
  passwordHash: string;
  role: "ADMIN" | "USER";
  createdAt: string;
}

interface Product {
  id: number;
  productName: string;
  description: string;
  category: string;
  brand: string;
  price: number;
  quantity: number;
  imageUrl: string;
  createdAt: string;
  updatedAt: string;
}

const users: User[] = [
  {
    id: 1,
    fullName: "System Admin",
    email: "admin@ecommerce.com",
    passwordHash: bcrypt.hashSync("admin123", 10),
    role: "ADMIN",
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    fullName: "Standard User",
    email: "user@ecommerce.com",
    passwordHash: bcrypt.hashSync("user123", 10),
    role: "USER",
    createdAt: new Date().toISOString(),
  }
];

let products: Product[] = [
  {
    id: 1,
    productName: "iPhone 15 Pro",
    description: "Experience the ultimate iPhone with titanium casing, the powerful A17 Pro chip, and a progressive 48MP main camera system.",
    category: "Electronics",
    brand: "Apple",
    price: 999.99,
    quantity: 45,
    imageUrl: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 2,
    productName: "Sony WH-1000XM5",
    description: "Industry-leading wireless noise-canceling headphones featuring stunning audio fidelity, long-wear comfort, and up to 30 hours of battery life.",
    category: "Electronics",
    brand: "Sony",
    price: 398.00,
    quantity: 120,
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 3,
    productName: "Mechanical Keyboard",
    description: "Compact 75% hot-swappable tactile mechanical keyboard with vibrant RGB backlighting and premium linear red switches.",
    category: "Electronics",
    brand: "Keychron",
    price: 89.99,
    quantity: 75,
    imageUrl: "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 4,
    productName: "Air Max Running Shoes",
    description: "Premium fitness sneakers delivering cloud-like active performance cushioning, breathable knit mesh, and dynamic traction support.",
    category: "Clothing",
    brand: "Nike",
    price: 149.99,
    quantity: 60,
    imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 5,
    productName: "Classic Denim Jacket",
    description: "Timeless trucker denim jacket in a beautiful indigo wash, durable triple-stitch construction, and a comfortable regular fit.",
    category: "Clothing",
    brand: "Levi's",
    price: 79.50,
    quantity: 35,
    imageUrl: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 6,
    productName: "Instant Pot Duo Plus",
    description: "Versatile 9-in-1 multi-use slow cooker, electric pressure cooker, sterilizer, yogurt maker, and food steamer with status display.",
    category: "Home & Kitchen",
    brand: "Instant Pot",
    price: 129.99,
    quantity: 110,
    imageUrl: "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 7,
    productName: "Ergonomic Office Chair",
    description: "Sleek professional task chair with dynamic posture lumbar support, premium breathable double-mesh back, and 3D adjustable armrests.",
    category: "Home & Kitchen",
    brand: "Steelcase",
    price: 499.00,
    quantity: 25,
    imageUrl: "https://images.unsplash.com/photo-1505797149-43b0069ec26b?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 8,
    productName: "Vaccum Insulated Water Bottle",
    description: "Rustproof 18/8 food-grade stainless steel double-wall athletic bottle keeping cold beverages refreshing for up to 24 hours.",
    category: "Sports & Outdoors",
    brand: "Hydro Flask",
    price: 34.95,
    quantity: 350,
    imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

let nextUserId = 3;
let nextProductId = 9;

// Authentication Middleware
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Access token is missing or invalid" });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: "Token is expired or invalid" });
    }
    req.user = user;
    next();
  });
}

function requireAdmin(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== "ADMIN") {
    return res.status(403).json({ message: "Access denied. Admin role required." });
  }
  next();
}

// REST APIs

// Health indicator
app.get("/api/health", (req, res) => {
  res.json({ status: "UP", message: "Spring Boot replication server running flawlessly!" });
});

// Authentication endpoints
app.post("/api/auth/register", (req, res) => {
  const { fullName, email, password, role } = req.body;

  if (!fullName || !email || !password) {
    return res.status(400).json({ message: "Full Name, Email, and Password are required" });
  }

  const existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ message: "Email is already registered" });
  }

  const assignedRole = role === "ADMIN" ? "ADMIN" : "USER";
  const passwordHash = bcrypt.hashSync(password, 10);

  const newUser: User = {
    id: nextUserId++,
    fullName,
    email: email.toLowerCase(),
    passwordHash,
    role: assignedRole,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);

  // Return formatted payload mirroring JWT response
  const responseUser = {
    id: newUser.id,
    fullName: newUser.fullName,
    email: newUser.email,
    role: newUser.role,
    createdAt: newUser.createdAt,
  };

  res.status(201).json(responseUser);
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ message: "Invalid email or matching password" });
  }

  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role, fullName: user.fullName },
    JWT_SECRET,
    { expiresIn: "8h" }
  );

  res.json({
    token,
    role: user.role,
    email: user.email,
    fullName: user.fullName,
    userId: user.id,
  });
});

// Products routes

// Search products route (Placed first to avoid conflict with /api/products/:id)
app.get("/api/products/search", (req, res) => {
  const keyword = (req.query.keyword as string || "").toLowerCase();
  
  let filtered = products;

  if (keyword) {
    filtered = products.filter(
      (p) =>
        p.productName.toLowerCase().includes(keyword) ||
        p.description.toLowerCase().includes(keyword) ||
        p.brand.toLowerCase().includes(keyword) ||
        p.category.toLowerCase().includes(keyword)
    );
  }

  // Handle pagination on search results
  const page = parseInt(req.query.page as string || "0");
  const size = parseInt(req.query.size as string || "10");
  const sortBy = (req.query.sortBy as string || "price");
  const direction = (req.query.direction as string || "asc").toLowerCase();

  // Sorting
  filtered.sort((a: any, b: any) => {
    let valA = a[sortBy];
    let valB = b[sortBy];

    if (typeof valA === "string") valA = valA.toLowerCase();
    if (typeof valB === "string") valB = valB.toLowerCase();

    if (valA < valB) return direction === "asc" ? -1 : 1;
    if (valA > valB) return direction === "asc" ? 1 : -1;
    return 0;
  });

  const totalElements = filtered.length;
  const totalPages = Math.ceil(totalElements / size);
  const offset = page * size;
  const content = filtered.slice(offset, offset + size);

  res.json({
    content,
    pageNumber: page,
    pageSize: size,
    totalElements,
    totalPages,
    last: page >= totalPages - 1,
  });
});

// GET all products with pagination and sorting
app.get("/api/products", (req, res) => {
  const page = parseInt(req.query.page as string || "0");
  const size = parseInt(req.query.size as string || "10");
  const sortBy = (req.query.sortBy as string || "price");
  const direction = (req.query.direction as string || "asc").toLowerCase();

  let result = [...products];

  // Apply sorting
  result.sort((a: any, b: any) => {
    let valA = a[sortBy];
    let valB = b[sortBy];

    if (valA === undefined) return 1;
    if (valB === undefined) return -1;

    if (typeof valA === "string") valA = valA.toLowerCase();
    if (typeof valB === "string") valB = valB.toLowerCase();

    if (valA < valB) return direction === "asc" ? -1 : 1;
    if (valA > valB) return direction === "asc" ? 1 : -1;
    return 0;
  });

  const totalElements = result.length;
  const totalPages = Math.ceil(totalElements / size);
  const offset = page * size;
  const content = result.slice(offset, offset + size);

  res.json({
    content,
    pageNumber: page,
    pageSize: size,
    totalElements,
    totalPages,
    last: page >= totalPages - 1,
  });
});

// GET single product
app.get("/api/products/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const product = products.find((p) => p.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found with ID " + id });
  }

  res.json(product);
});

// POST create product (Admin only)
app.post("/api/products", authenticateToken, requireAdmin, (req, res) => {
  const { productName, description, category, brand, price, quantity, imageUrl } = req.body;

  if (!productName || !category || !brand || price === undefined || quantity === undefined) {
    return res.status(400).json({ message: "Product Name, Category, Brand, Price and Quantity are required" });
  }

  if (price <= 0) {
    return res.status(400).json({ message: "Price must be greater than zero" });
  }

  if (quantity < 0) {
    return res.status(400).json({ message: "Quantity cannot be negative" });
  }

  const newProduct: Product = {
    id: nextProductId++,
    productName,
    description: description || "",
    category,
    brand,
    price: parseFloat(price),
    quantity: parseInt(quantity),
    imageUrl: imageUrl || "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=500&auto=format&fit=crop&q=60",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
});

// PUT update product (Admin only)
app.put("/api/products/:id", authenticateToken, requireAdmin, (req, res) => {
  const id = parseInt(req.params.id);
  const index = products.findIndex((p) => p.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Product not found with ID " + id });
  }

  const { productName, description, category, brand, price, quantity, imageUrl } = req.body;

  if (!productName || !category || !brand || price === undefined || quantity === undefined) {
    return res.status(400).json({ message: "Product Name, Category, Brand, Price, and Quantity are required" });
  }

  if (price <= 0) {
    return res.status(400).json({ message: "Price must be positive" });
  }

  if (quantity < 0) {
    return res.status(400).json({ message: "Quantity cannot be negative" });
  }

  const updatedProduct: Product = {
    ...products[index],
    productName,
    description: description || "",
    category,
    brand,
    price: parseFloat(price),
    quantity: parseInt(quantity),
    imageUrl: imageUrl || products[index].imageUrl,
    updatedAt: new Date().toISOString(),
  };

  products[index] = updatedProduct;
  res.json(updatedProduct);
});

// DELETE product (Admin only)
app.delete("/api/products/:id", authenticateToken, requireAdmin, (req, res) => {
  const id = parseInt(req.params.id);
  const index = products.findIndex((p) => p.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Product not found with ID " + id });
  }

  products.splice(index, 1);
  res.json({ message: "Product successfully deleted with resource ID " + id });
});

// Vite Middleware runner for development and Production serving behavior
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
