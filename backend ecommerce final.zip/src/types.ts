export interface User {
  id: number;
  fullName: string;
  email: string;
  role: "ADMIN" | "USER";
  createdAt: string;
}

export interface Product {
  id: number;
  productName: string;
  description: string;
  category: string;
  brand: string;
  price: number;
  quantity: number;
  imageUrl: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  token: string;
  role: "ADMIN" | "USER";
  email: string;
  fullName: string;
  userId: number;
}

export interface PaginatedProducts {
  content: Product[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}
