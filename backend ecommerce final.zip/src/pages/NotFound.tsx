import React from "react";
import { Link } from "react-router-dom";
import { AlertCircle, HelpCircle, LayoutDashboard } from "lucide-react";
import { motion } from "motion/react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4 font-sans text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="max-w-md w-full bg-white border border-slate-200 shadow-xl rounded-2xl p-8 space-y-6"
      >
        <div className="h-16 w-16 bg-slate-100 text-slate-500 rounded-2xl flex items-center justify-center mx-auto border border-slate-200 shadow-sm font-black text-xl font-mono">
          404
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Resource Not Found</h1>
          <p className="text-slate-500 text-sm">
            We couldn't locate the specified page. It may have been relocated, or is temporarily offline.
          </p>
        </div>

        <div className="pt-2">
          <Link
            to="/dashboard"
            className="flex items-center justify-center gap-2 w-full py-2.5 bg-slate-900 hover:bg-slate-950 text-white rounded-xl text-xs font-bold transition shadow"
          >
            <LayoutDashboard size={14} />
            <span>Return to Dashboard</span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
