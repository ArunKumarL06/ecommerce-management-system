import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import { useNavigate, useParams, Link } from "react-router-dom";
import { motion } from "motion/react";
import { 
  ArrowLeft, 
  Save, 
  AlertCircle, 
  Info, 
  Tag, 
  Layers, 
  DollarSign, 
  BarChart, 
  Image,
  Sparkles
} from "lucide-react";

export default function EditProduct() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams();

  // Route protection - Admin only can edit
  useEffect(() => {
    if (user && user.role !== "ADMIN") {
      navigate("/unauthorized");
    }
  }, [user, navigate]);

  // Form states
  const [productName, setProductName] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("Electronics");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load existing product details
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await api.get(`/products/${id}`);
        const p = response.data;
        setProductName(p.productName);
        setBrand(p.brand);
        setCategory(p.category);
        setPrice(String(p.price));
        setQuantity(String(p.quantity));
        setDescription(p.description || "");
        setImageUrl(p.imageUrl || "");
      } catch (err: any) {
        console.error(err);
        setError(err.response?.data?.message || "Failed to load product details from server.");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchProduct();
    }
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Client side Spring constraint mirroring validation
    if (!productName.trim()) {
      setError("Product Name is required and must not be blank.");
      return;
    }
    if (!brand.trim()) {
      setError("Brand is required.");
      return;
    }
    const numPrice = parseFloat(price);
    if (isNaN(numPrice) || numPrice <= 0) {
      setError("Price has @Positive validation constraints — it must be greater than zero.");
      return;
    }
    const numQty = parseInt(quantity);
    if (isNaN(numQty) || numQty < 0) {
      setError("Quantity has @NotNull / @PositiveOrZero validations — it must not be negative.");
      return;
    }

    setSaving(true);
    setError(null);

    const payload = {
      productName: productName.trim(),
      brand: brand.trim(),
      category: category,
      price: numPrice,
      quantity: numQty,
      description: description.trim(),
      imageUrl: imageUrl.trim() || undefined,
    };

    try {
      await api.put(`/products/${id}`, payload);
      navigate("/products");
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to edit product records.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto space-y-6">
        
        {/* Breadcrumb row */}
        <div className="flex items-center gap-2">
          <Link 
            to="/products" 
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition"
          >
            <ArrowLeft size={14} />
            <span>Back to Products</span>
          </Link>
        </div>

        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Modify Inventory Listing</h1>
          <p className="text-slate-500 text-sm mt-0.5">Edit active metrics, properties, and specifications for standard SKU item.</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center gap-3 text-sm">
            <AlertCircle size={18} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {loading ? (
          <div className="text-center py-20 bg-white border border-slate-200 rounded-2xl">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900 mx-auto"></div>
            <p className="text-slate-400 mt-4 text-xs font-semibold">Pulling original SKU parameters from database...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden divide-y divide-slate-100 font-sans">
            
            {/* Section 1: Core Specs */}
            <div className="p-6 space-y-5">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Info size={14} />
                Basic Product Parameters
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Product Title *</label>
                  <div className="mt-1.5 relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Tag size={15} />
                    </span>
                    <input
                      type="text"
                      required
                      value={productName}
                      onChange={(e) => setProductName(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                      placeholder="e.g. UltraFit Training Watch"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Brand Partner *</label>
                  <div className="mt-1.5 relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Sparkles size={15} />
                    </span>
                    <input
                      type="text"
                      required
                      value={brand}
                      onChange={(e) => setBrand(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                      placeholder="e.g. Garmin"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Category Hierarchy *</label>
                <div className="mt-1.5 relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Layers size={15} />
                  </span>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                  >
                    <option value="Electronics">Electronics</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Home & Kitchen">Home & Kitchen</option>
                    <option value="Books">Books</option>
                    <option value="Sports & Outdoors">Sports & Outdoors</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Section 2: Economics */}
            <div className="p-6 space-y-5">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <DollarSign size={14} />
                Pricing & Warehousing Logistics
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Retail Price ($USD) *</label>
                  <div className="mt-1.5 relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <DollarSign size={15} />
                    </span>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      required
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-550 text-slate-500 uppercase tracking-wide">Storage Stock Quantity *</label>
                  <div className="mt-1.5 relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <BarChart size={15} />
                    </span>
                    <input
                      type="number"
                      min="0"
                      required
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 3: Presentation and copy */}
            <div className="p-6 space-y-5">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Image size={14} />
                Product Copy & Presentation assets
              </h3>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Unsplash Image Address URL</label>
                <div className="mt-1.5 relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Image size={15} />
                  </span>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                    placeholder="https://images.unsplash.com/photo-..."
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide">Product Description Box</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="mt-1.5 block w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 text-sm bg-slate-50/50"
                  placeholder="Give a thorough breakdown of materials, performance, features, and specs..."
                />
              </div>
            </div>

            {/* Actions footer */}
            <div className="p-6 bg-slate-50 flex items-center justify-end gap-3.5 border-t border-slate-100">
              <Link
                to="/products"
                className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-semibold"
              >
                Cancel Changes
              </Link>
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-950 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all flex items-center gap-2 cursor-pointer shadow"
              >
                <Save size={14} />
                {saving ? "Updating..." : "Save Product Listing"}
              </button>
            </div>

          </form>
        )}
      </div>
    </DashboardLayout>
  );
}
