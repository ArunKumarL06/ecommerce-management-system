import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../services/api";
import { Product } from "../types";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { 
  Package, 
  Grid, 
  Layers, 
  AlertCircle, 
  ArrowRight,
  TrendingUp,
  Clock,
  Briefcase
} from "lucide-react";

export default function Dashboard() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAllProducts = async () => {
      try {
        // Fetch a larger page size to compile accurate dashboard stats
        const response = await api.get("/products?size=100");
        setProducts(response.data.content || []);
      } catch (err: any) {
        console.error(err);
        setError(err.response?.data?.message || "Failed to load warehouse metrics");
      } finally {
        setLoading(false);
      }
    };

    fetchAllProducts();
  }, []);

  // Compute metrics
  const totalProducts = products.length;
  const categories = Array.from(new Set(products.map((p) => p.category)));
  const totalCategories = categories.length;
  const totalInventory = products.reduce((acc, p) => acc + p.quantity, 0);
  const totalValue = products.reduce((acc, p) => acc + p.price * p.quantity, 0);

  // Sorting products by createdAt or id descending to show "Recent"
  const recentProducts = [...products]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const stats = [
    {
      name: "Total Catalog Products",
      value: totalProducts,
      desc: "Unique items in stock",
      icon: Package,
      color: "bg-blue-50 text-blue-700 border-blue-100",
    },
    {
      name: "Product Categories",
      value: totalCategories,
      desc: `${totalCategories} unique core groups`,
      icon: Layers,
      color: "bg-emerald-50 text-emerald-700 border-emerald-100",
    },
    {
      name: "Total Physical Inventory",
      value: totalInventory,
      desc: "Physical counts tracked",
      icon: Grid,
      color: "bg-purple-50 text-purple-700 border-purple-100",
    },
    {
      name: "Estimated Stock Value",
      value: `$${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      desc: "Based on retail listing",
      icon: TrendingUp,
      color: "bg-amber-50 text-amber-700 border-amber-100",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Executive Dashboard</h1>
          <p className="text-slate-500 mt-1">Real-time metrics and live logistics summaries of your e-commerce ecosystem.</p>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center p-12 min-h-[300px]">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-slate-900"></div>
            <p className="text-slate-500 mt-3 text-sm">Compiling warehousing audit metrics...</p>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center gap-3">
            <AlertCircle size={20} className="shrink-0" />
            <div>
              <p className="font-semibold">Logistics Sync Error</p>
              <p className="text-sm text-red-600/80">{error}</p>
            </div>
          </div>
        ) : (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat, idx) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={stat.name}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: idx * 0.05 }}
                    className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm flex items-start gap-4 relative overflow-hidden"
                  >
                    <div className={`p-3 rounded-xl border ${stat.color}`}>
                      <Icon size={20} />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{stat.name}</span>
                      <span className="text-2xl font-black text-slate-800 mt-1">{stat.value}</span>
                      <span className="text-xs text-slate-500 mt-1 font-medium">{stat.desc}</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Recent activity & Category distribution details */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              {/* Product list */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm lg:col-span-2 overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock size={18} className="text-slate-400" />
                    <h3 className="font-bold text-slate-800">Recently Cataloged Items</h3>
                  </div>
                  <Link 
                    to="/products" 
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 hover:underline underline-offset-4"
                  >
                    <span>View all products</span>
                    <ArrowRight size={12} />
                  </Link>
                </div>

                <div className="overflow-x-auto">
                  {recentProducts.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-sm">
                      No products cataloged in database yet.
                    </div>
                  ) : (
                    <table className="min-w-full divide-y divide-slate-100 text-sm">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-5 py-3 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Product Name</th>
                          <th className="px-5 py-3 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Brand</th>
                          <th className="px-5 py-3 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Price</th>
                          <th className="px-5 py-3 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Quantity</th>
                          <th className="px-5 py-3 text-right text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {recentProducts.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50/50 transition-all font-medium">
                            <td className="px-5 py-3 flex items-center gap-3">
                              <img 
                                src={p.imageUrl} 
                                alt={p.productName} 
                                referrerPolicy="no-referrer"
                                className="h-9 w-9 rounded-lg object-cover bg-slate-100 border border-slate-200" 
                              />
                              <div className="flex flex-col">
                                <span className="font-bold text-slate-800">{p.productName}</span>
                                <span className="text-xs text-slate-400 font-medium">{p.category}</span>
                              </div>
                            </td>
                            <td className="px-5 py-3 text-slate-600">{p.brand}</td>
                            <td className="px-5 py-3 font-semibold text-slate-800">${p.price.toFixed(2)}</td>
                            <td className="px-5 py-3 text-slate-600 font-mono">{p.quantity} units</td>
                            <td className="px-5 py-3 text-right">
                              <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                p.quantity > 50 
                                  ? "bg-emerald-50 text-emerald-700 border border-emerald-100" 
                                  : p.quantity > 0 
                                    ? "bg-amber-50 text-amber-700 border border-amber-100" 
                                    : "bg-red-50 text-red-700 border border-red-100"
                              }`}>
                                {p.quantity > 50 ? "In Stock" : p.quantity > 0 ? "Low Stock" : "Out of Stock"}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>

              {/* Side information list */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 space-y-6">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                  <Briefcase size={18} className="text-slate-400" />
                  <h3 className="font-bold text-slate-800">Operational Summary</h3>
                </div>

                <div className="space-y-4">
                  <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl">
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Quick Audit Check</h5>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      All products in stock are cataloged with positive quantities. Out of stock alarms are active for any item reaching 0 storage counts.
                    </p>
                  </div>

                  <div className="space-y-2.5">
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wide">Category Distribution</h5>
                    <div className="space-y-2 text-xs font-semibold">
                      {categories.map((cat) => {
                        const count = products.filter((p) => p.category === cat).length;
                        const percentage = count > 0 ? Math.round((count / products.length) * 100) : 0;
                        return (
                          <div key={cat} className="space-y-1">
                            <div className="flex justify-between text-slate-600">
                              <span>{cat}</span>
                              <span className="text-slate-400">{count} products ({percentage}%)</span>
                            </div>
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div 
                                className="bg-slate-800 h-1.5 rounded-full" 
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
