import axios from "axios";

// Check if running inside AI Studio preview or standalone localhost:8087
// This ensures the application works immediately in the live playground,
// while remaining fully prepared for production local Spring Boot connection on port 8087.
const BASE_URL = window.location.port === "3000" || window.location.hostname.includes("run.app")
  ? "/api"
  : "http://localhost:8087/api";

const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor for API calls - injecting JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for API calls - handling unauthorized or expired tokens
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    const originalRequest = error.config;
    // Mirror standard JWT extraction error behaviors
    if (error.response && error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      // Logging or triggering logout behavior if needed
      console.warn("Unauthorized access detected (401). Routing back to authentication or clearing stale credentials...");
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      localStorage.removeItem("fullName");
      localStorage.removeItem("email");
      localStorage.removeItem("userId");
      
      // We can let the component handling catch this and redirect to login
    }
    return Promise.reject(error);
  }
);

export default api;
