# Enterprise Full-Stack E-Commerce Product Management System

An industry-level, fully resilient e-commerce product management panel utilizing a **layered software architecture** on both ends. This workspace is packaged for instant developer hand-off, featuring:

1. **Active Live Preview (Vite + Express Emulation Server)**: Runs automatically within Google AI Studio on port 3000. It replicates the Spring Security filter logic, user roles (`ADMIN`/`USER`), database seed records, search, sorting, and pagination flawlessly.
2. **Production-Ready Spring Boot 3 Backend Service (`/ecommerce-backend/`)**: Built with **Java 21, Maven, Spring Security 6.x, Spring Data JPA, JWT Authentication**, and comprehensive global validation. Built on stable SOLID patterns and tested via JUnit 5.
3. **Responsive React Vite Frontend (`/`)**: A modular template styled with tailored high-contrast premium typography, Axios interceptors, responsive mobile navigation drawers, and dynamic metric visualizations.

---

## 📂 System Project Structure

```text
├── ecommerce-backend/                      # Production Java Spring Boot 3.x Maven project
│   ├── pom.xml                             # Maven Dependencies
│   └── src/
│       ├── main/
│       │   ├── java/com/ecommerce/
│       │   │   ├── ProductManagementApplication.java # Entry Point
│       │   │   ├── config/             # Spring Security, JWT Filters & Claims configs
│       │   │   ├── controller/         # REST Controllers with Swagger annotations
│       │   │   ├── dto/                # Request / Response custom validation schemas
│       │   │   ├── entity/             # JPA entity mappings (User, Product, Role)
│       │   │   ├── exception/          # Global entity Exception REST advisors
│       │   │   ├── repository/         # Data layer repositories
│       │   │   └── service/            # Core business transactional mappers & services
│       │   └── resources/
│       │       ├── application.properties # Server port 8087 & MySQL bindings
│       │       ├── schema.sql          # DB DDL constraints 
│       │       └── data.sql            # Core stock inventories seed script
│       └── test/                           # JUnit 5 & Mockito test suite
└── src/                                    # Front-End React 18 Application (Vite bundle)
    ├── components/                         # Layout sidebars & global headers
    ├── context/                            # Token handlers & global session hook state
    ├── pages/                              # Modules: Login, Register, Audit Catalog...
    └── services/                           # Axios api interceptor client instance
```

---

## 🛠️ Local Development & Running the Project

### 1. Backend Service (`ecommerce-backend`)

#### Prerequisites
- **Java JDK 21**
- **Apache Maven 3.9+**
- **MySQL Server 8.0+**

#### Database Configuration
1. Open your MySQL client and run the following command to bootstrap the database container:
   ```sql
   CREATE DATABASE ecommerce_db;
   ```
2. The schema definitions are pre-configured to populate automatically. To verify, the SQL structure is located in:
   - `ecommerce-backend/src/main/resources/schema.sql` (Creates `users` and `products` tables).
   - `ecommerce-backend/src/main/resources/data.sql` (Seeds demo admin/user accounts and inventory).

#### Running in IntelliJ IDEA 🚀
1. Open IntelliJ IDEA, select **File > Open**, and select the `/ecommerce-backend` directory.
2. Allow IntelliJ to complete synchronization of the Maven dependency tree from `pom.xml`.
3. Open `src/main/resources/application.properties` and verify your local MySQL username/password details:
   ```properties
   spring.datasource.username=root
   spring.datasource.password=your_mysql_password
   ```
4. Right-click on `ProductManagementApplication.java` inside `src/main/java/com/ecommerce/` and click **Run**.
5. The REST APIs will boot up active on path: **`http://localhost:8087`**.
6. Access the live Swagger/OpenAPI documentation panel at: **`http://localhost:8087/swagger-ui.html`**.

#### Running in VS Code 💻
1. Open VS Code, select **Open Folder...**, and select the `/ecommerce-backend` directory.
2. Install the **Extension Pack for Java** and **Spring Boot Extension Pack** recommended extensions.
3. Open the command palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) and choose `Spring Boot: Run/Debug`.
4. Command-Line fallback:
   ```bash
   mvn clean spring-boot:run
   ```

---

### 2. Frontend Application (`/`)

#### Prerequisites
- **Node.js 18+**

#### Configuration to point to port 8087
In `src/services/api.js`, the standard instance base URL detects environment variables automatically:
- When running in local dev with Spring Boot: queries are routed to `http://localhost:8087/api`
- When running in sandbox environment: routed natively to local emulation `/api` routes on port 3000.

#### Running in VS Code or Command-Line ⚡
1. Open the project root in VS Code.
2. Run package installations:
   ```bash
   npm install
   ```
3. Boot up Vite dev server:
   ```bash
   npm run dev
   ```
4. Access the web interface at **`http://localhost:3000`** in your browser.

---

## 🔑 Default Credentials

Use these pre-configured user files to complete end-to-end audits of standard credentials inside the dashboard:

| Role | Username / Email | Password | Allowed Scopes / Capabilities |
| :--- | :--- | :--- | :--- |
| **ADMIN** | `admin@ecommerce.com` | `admin123` | Full Stock Management, Add, Edit, Delete, Read |
| **USER** | `user@ecommerce.com` | `user123` | Read-only Catalog listing, Search filters, Details |
