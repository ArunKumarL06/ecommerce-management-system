import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { 
  LayoutDashboard, 
  Package, 
  PlusCircle, 
  LogOut, 
  User as UserIcon, 
  Shield, 
  Menu, 
  X 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const navItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: LayoutDashboard,
      roles: ["ADMIN", "USER"],
    },
    {
      name: "Product Catalog",
      path: "/products",
      icon: Package,
      roles: ["ADMIN", "USER"],
    },
    {
      name: "Add New Product",
      path: "/products/add",
      icon: PlusCircle,
      roles: ["ADMIN"],
    },
  ];

  const filteredNavItems = navItems.filter(item => user && item.roles.includes(user.role));

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Decorative top aesthetic line */}
      <div className="h-1 bg-slate-900 w-full" />

      {/* Top navbar */}
      <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-4 sm:px-6 md:px-8 shrink-0 z-20 sticky top-0 shadow-sm">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all"
            id="mobile-menu-toggle-btn"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-slate-900 flex items-center justify-center text-white font-black text-sm">
              E
            </div>
            <span className="text-md font-bold text-slate-800 tracking-tight hidden sm:inline-block">E-Commerce Panel</span>
          </Link>
        </div>

        {/* User profile & controls */}
        {user && (
          <div className="flex items-center gap-3 md:gap-4">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-sm font-semibold text-slate-800">{user.fullName}</span>
              <span className="text-xs font-mono text-slate-400 capitalize flex items-center justify-end gap-1">
                <Shield size={10} className="text-slate-400" />
                {user.role}
              </span>
            </div>

            <div className="h-9 w-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center border border-slate-200">
              <UserIcon size={16} />
            </div>

            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 hover:border-slate-300 rounded-xl text-xs font-medium cursor-pointer transition-all"
              id="header-logout-btn"
            >
              <LogOut size={13} />
              <span className="hidden md:inline">Sign Out</span>
            </button>
          </div>
        )}
      </header>

      {/* Main Container */}
      <div className="flex flex-1 relative overflow-hidden">
        {/* Sidebar for Desktop */}
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 p-4 shrink-0 justify-between">
          <div className="space-y-1">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-widest px-3 mb-3">
              Operational Navigation
            </div>
            <nav className="space-y-1">
              {filteredNavItems.map((item) => {
                const isActive = location.pathname === item.path;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                      isActive 
                        ? "bg-slate-900 text-white shadow-sm" 
                        : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                    }`}
                  >
                    <Icon size={18} className={isActive ? "text-white" : "text-slate-400"} />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-2.5 mt-auto">
            <Shield size={16} className={user?.role === "ADMIN" ? "text-emerald-500" : "text-blue-500"} />
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-bold text-slate-700 truncate">{user?.fullName}</span>
              <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">
                {user?.role} Context
              </span>
            </div>
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileOpen && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.4 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileOpen(false)}
                className="fixed inset-0 bg-slate-950 z-30 md:hidden"
              />

              {/* Sidebar content */}
              <motion.aside
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "tween", duration: 0.25 }}
                className="fixed inset-y-0 left-0 w-64 bg-white z-40 p-4 flex flex-col justify-between shadow-2xl md:hidden"
              >
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-800 tracking-tight">E-Commerce Menu</span>
                    <button 
                      onClick={() => setMobileOpen(false)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                    >
                      <X size={18} />
                    </button>
                  </div>
                  
                  <nav className="space-y-1.5">
                    {filteredNavItems.map((item) => {
                      const isActive = location.pathname === item.path;
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={() => setMobileOpen(false)}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                            isActive 
                              ? "bg-slate-900 text-white shadow-sm" 
                              : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                          }`}
                        >
                          <Icon size={18} className={isActive ? "text-white" : "text-slate-400"} />
                          <span>{item.name}</span>
                        </Link>
                      );
                    })}
                  </nav>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-2.5 p-2 bg-slate-50 rounded-xl">
                    <div className="h-8 w-8 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center font-bold">
                      {user?.fullName.charAt(0)}
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-xs font-bold text-slate-700 truncate">{user?.fullName}</span>
                      <span className="text-[10px] uppercase text-emerald-500 font-bold">{user?.role}</span>
                    </div>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center justify-center gap-2 py-2 border border-slate-200 text-slate-600 hover:bg-red-50 hover:border-red-100 hover:text-red-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                  >
                    <LogOut size={14} />
                    <span>Sign Out</span>
                  </button>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Dynamic page target */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
