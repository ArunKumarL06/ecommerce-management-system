USE ecommerce_db;

-- Seed Users (Passwords are BCrypt hashes: admin123, user123)
INSERT INTO users (full_name, email, password, role, created_at)
VALUES 
('System Admin', 'admin@ecommerce.com', '$2a$10$O9wG/h7XUCO0YshfJ/sOLeCclC7Tia7PkaDkHly7f9Y9q09nswR3W', 'ADMIN', NOW())
ON DUPLICATE KEY UPDATE email=email;

INSERT INTO users (full_name, email, password, role, created_at)
VALUES 
('Standard User', 'user@ecommerce.com', '$2a$10$vD2/6r9xMoxYV0C7v6R44.VwXkZ7j7Z81P3D9X8r789rnsS38u7yW', 'USER', NOW())
ON DUPLICATE KEY UPDATE email=email;

-- Seed Products
INSERT INTO products (product_name, description, category, brand, price, quantity, image_url, created_at, updated_at)
VALUES
('iPhone 15 Pro', 'Experience the ultimate iPhone with titanium casing, the powerful A17 Pro chip, and a progressive 48MP main camera system.', 'Electronics', 'Apple', 999.99, 45, 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Sony WH-1000XM5', 'Industry-leading wireless noise-canceling headphones featuring stunning audio fidelity, long-wear comfort, and up to 30 hours of battery life.', 'Electronics', 'Sony', 398.00, 120, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Mechanical Keyboard', 'Compact 75% hot-swappable tactile mechanical keyboard with vibrant RGB backlighting and premium linear red switches.', 'Electronics', 'Keychron', 89.99, 75, 'https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Air Max Running Shoes', 'Premium fitness sneakers delivering cloud-like active performance cushioning, breathable knit mesh, and dynamic traction support.', 'Clothing', 'Nike', 149.99, 60, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Classic Denim Jacket', 'Timeless trucker denim jacket in a beautiful indigo wash, durable triple-stitch construction, and a comfortable regular fit.', 'Clothing', 'Levi''s', 79.50, 35, 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Instant Pot Duo Plus', 'Versatile 9-in-1 multi-use slow cooker, electric pressure cooker, sterilizer, yogurt maker, and food steamer with status display.', 'Home & Kitchen', 'Instant Pot', 129.99, 110, 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Ergonomic Office Chair', 'Sleek professional task chair with dynamic posture lumbar support, premium breathable double-mesh back, and 3D adjustable armrests.', 'Home & Kitchen', 'Steelcase', 499.00, 25, 'https://images.unsplash.com/photo-1505797149-43b0069ec26b?w=500&auto=format&fit=crop&q=60', NOW(), NOW()),
('Vaccum Insulated Water Bottle', 'Rustproof 18/8 food-grade stainless steel double-wall athletic bottle keeping cold beverages refreshing for up to 24 hours.', 'Sports & Outdoors', 'Hydro Flask', 34.95, 350, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500&auto=format&fit=crop&q=60', NOW(), NOW());
